﻿namespace MESTool
{
    class EndianBinary
    {
        public enum Endian
        {
            Little,
            Big
        }
    }
}
